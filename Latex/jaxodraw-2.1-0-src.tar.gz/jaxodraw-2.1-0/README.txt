For build instructions and general information see the file src/doc/README.
For licensing information see the files in src/doc/legal/.