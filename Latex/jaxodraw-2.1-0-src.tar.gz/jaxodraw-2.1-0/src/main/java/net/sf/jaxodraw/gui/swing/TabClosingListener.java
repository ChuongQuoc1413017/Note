/**
 *  Licensed under GPL. For more information, see
 *    http://jaxodraw.sourceforge.net/license.html
 *  or the LICENSE file in the jaxodraw distribution.
 */

package net.sf.jaxodraw.gui.swing;

import java.util.EventListener;

/**
 * Listen to tab closing events.
 */
public interface TabClosingListener extends EventListener {
    /**
     * The user has requested to close a tab.
     *
     * @param e The closing event.
     */
    void closing(TabClosingEvent e);
}
