/**
 *  Licensed under GPL. For more information, see
 *    http://jaxodraw.sourceforge.net/license.html
 *  or the LICENSE file in the jaxodraw distribution.
 */
package net.sf.jaxodraw.gui.panel.edit;

import java.awt.event.ActionListener;
import java.awt.event.ItemListener;

import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentListener;


/** A listener for edit panels.
 * @since 2.0
 */
public interface JaxoEditPanelListener extends ActionListener, ChangeListener,
    ItemListener, DocumentListener {
    // just a union of DocumentListener, ItemListener,
    // ActionListener and ChangeListener
}
