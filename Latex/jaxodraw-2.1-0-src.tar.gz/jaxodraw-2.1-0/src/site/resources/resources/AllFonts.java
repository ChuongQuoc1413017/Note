import java.awt.*;


class AllFonts {
    public static void main(String[] args) {
        GraphicsEnvironment ge =
            GraphicsEnvironment.getLocalGraphicsEnvironment();
        Font[] allFonts = ge.getAllFonts();

        int len = allFonts.length;

        for (int i = 0; i < len; i++) {
            System.out.println(allFonts[i].toString());

            try {
                if (allFonts[i].canDisplay('a')) {
                    System.out.println("can display");
                } else {
                    System.out.println("can NOT display");
                }
            } catch (Exception e) {
                System.out.println("!!! Exception !!!" + e);
            }
        }
    }
}
